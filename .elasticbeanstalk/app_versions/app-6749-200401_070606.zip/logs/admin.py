from django.contrib import admin
from .models import Log

admin.site.register(Log)
