from django.contrib import admin
# from .models import MasterpointsCopy, MasterpointDetails, MasterpointsClubs
#
# admin.site.register(MasterpointsCopy)
# admin.site.register(MasterpointDetails)
# admin.site.register(MasterpointsClubs)
