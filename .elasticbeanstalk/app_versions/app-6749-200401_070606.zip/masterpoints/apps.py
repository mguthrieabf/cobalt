from django.apps import AppConfig


class MasterpointsConfig(AppConfig):
    name = 'masterpoints'
