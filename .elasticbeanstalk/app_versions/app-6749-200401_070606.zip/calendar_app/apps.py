from django.apps import AppConfig


class CalendarAppConfig(AppConfig):
    name = 'calendar_app'
